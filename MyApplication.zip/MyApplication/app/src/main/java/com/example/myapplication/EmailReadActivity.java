package com.example.myapplication;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.EmailComposeActivity;

public class EmailReadActivity extends AppCompatActivity {

    private TextView textViewEmailBody;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_read);

        TextView textViewFrom = findViewById(R.id.textViewFrom);
        TextView textViewTo = findViewById(R.id.textViewTo);
        TextView textViewSubject = findViewById(R.id.textViewSubject);
        textViewEmailBody = findViewById(R.id.textViewEmailBody);

        Button editButton = findViewById(R.id.editButton);
        Button sendButton = findViewById(R.id.sendButton);


        Intent intent = getIntent();
//        if (intent != null) {
            String from = intent.getStringExtra("from");
            String to = intent.getStringExtra("to");
            String subject = intent.getStringExtra("subject");
            String emailBody = intent.getStringExtra("emailBody");

            textViewFrom.setText("From: " + from);
            textViewTo.setText("To: " + to);
            textViewSubject.setText("Subject: " + subject);
            textViewEmailBody.setText(emailBody);
//        }

        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToComposeActivity();
            }
        });

//        sendButton.setOnClickListener(new View.OnClickListener() {
//           @Override
//            public void onClick(View v) {
//               navigateToComposeActivity();
//           }
                // Implement email sending functionality (if required).

//        });
    }

    private void navigateToComposeActivity() {
        Intent intent = new Intent(this, EmailComposeActivity.class);
        startActivity(intent);
    }
}
