package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class EmailComposeActivity extends AppCompatActivity {

    private EditText editTextFrom, editTextTo, editTextCC, editTextSubject, editTextEmailBody;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_compose);

        editTextFrom = findViewById(R.id.editTextFrom);
        editTextTo = findViewById(R.id.editTextTo);
        editTextCC = findViewById(R.id.editTextCC);
        editTextSubject = findViewById(R.id.editTextSubject);
        editTextEmailBody = findViewById(R.id.editTextEmailBody);
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        editTextFrom.setText(sharedPreferences.getString("from", ""));
        editTextTo.setText(sharedPreferences.getString("to", ""));
        editTextCC.setText(sharedPreferences.getString("cc", ""));
        editTextSubject.setText(sharedPreferences.getString("subject", ""));
        editTextEmailBody.setText(sharedPreferences.getString("emailBody", ""));


        Button clearButton = findViewById(R.id.clearButton);
        Button previewButton = findViewById(R.id.previewButton);

        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearFields();
            }
        });

        previewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                previewEmail();
            }


    });
    }
    protected void onPause() {
        super.onPause();

        // 在onPause中保存数据
        String from = editTextFrom.getText().toString();
        String to = editTextTo.getText().toString();
        String cc = editTextCC.getText().toString();
        String subject = editTextSubject.getText().toString();
        String emailBody = editTextEmailBody.getText().toString();

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("from", from);
        editor.putString("to", to);
        editor.putString("cc", cc);
        editor.putString("subject", subject);
        editor.putString("emailBody", emailBody);
        editor.apply();
    }

    private void clearFields() {
        editTextFrom.setText("");
        editTextTo.setText("");
        editTextCC.setText("");
        editTextSubject.setText("");
        editTextEmailBody.setText("");
    }

    private void previewEmail() {
        String from = editTextFrom.getText().toString();
        String to = editTextTo.getText().toString();
        String cc = editTextCC.getText().toString();
        String subject = editTextSubject.getText().toString();
        String emailBody = editTextEmailBody.getText().toString();

        Intent intent = new Intent(this, EmailReadActivity.class);
        intent.putExtra("from", from);
        intent.putExtra("to", to);
        intent.putExtra("cc", cc);
        intent.putExtra("subject", subject);
        intent.putExtra("emailBody", emailBody);

        startActivity(intent);
    }
}
